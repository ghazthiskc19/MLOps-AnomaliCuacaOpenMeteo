# 🌤️ MLOps-AnomaliCuacaOpenMeteo

**Sistem Otomatis Deteksi Anomali Data Cuaca Open-Meteo untuk Smart Farming Berbasis MLOps**

> Proyek MLOps end-to-end yang mendeteksi anomali data cuaca dari Open-Meteo API menggunakan Multiclass Classification untuk mendukung Smart Farming di area Malang, Jawa Timur.

---

## 📋 Deskripsi

Proyek ini berfokus pada domain **Internet of Things (IoT)** dan **Smart Agriculture** (Pertanian Pintar). Sistem ini menangani manajemen data metrik lingkungan yang dihasilkan oleh infrastruktur Smart Farming otomatis.

### Machine Learning Task

Pendekatan Machine Learning yang diterapkan adalah **Multiclass Classification** untuk deteksi dan diferensiasi anomali data cuaca ke dalam 3 kelas:

| Class | Label | Deskripsi |
|---|---|---|
| **0** | Normal State | Pembacaan sensor dalam rentang operasional wajar |
| **1** | Hardware Fault Anomaly | Indikasi kegagalan perangkat keras (stuck value, spiking, out-of-bounds) |
| **2** | Extreme Environmental Anomaly | Perubahan kondisi lingkungan ekstrem (gelombang panas, kekeringan) |

### Mengapa MLOps?

Data cuaca bersifat dinamis dan mengalami **Data Drift** (pergeseran distribusi saat pergantian musim) dan **Concept Drift** (perubahan definisi "anomali" di musim berbeda). Sistem MLOps dibutuhkan untuk:
- Monitoring model secara real-time
- Continuous Training otomatis saat drift terdeteksi
- Shadow Deployment untuk validasi model baru

---

## 🏗️ Struktur Proyek

```
MLOps-AnomaliCuacaOpenMeteo/
├── dags/                       # Apache Airflow DAGs
│   └── weather_ingestion_dag.py# DAG orkestrasi data ingestion per jam
├── data/
│   ├── raw/                    # Buffer data mentah (weather_raw_current.csv)
│   └── processed/              # Fitur diproses & dilabel (weather_features_v1.0.csv)
├── models/                     # Model artifacts (.pkl, .joblib)
├── src/                        # Source code Python utama
│   ├── __init__.py
│   ├── 0_data_ingestion.py      # Mengambil data API Open-Meteo
│   ├── 1_data_preprocessing.py  # Cleaning, label aturan, dan fitur
│   ├── 2_r2_sync.py             # Sinkronisasi Cloudflare R2
│   ├── 3_simulate_data.py       # Simulasi hardware fault dan drift
│   ├── 4_training_data.py       # Validasi data dan konteks histori
│   ├── 5_model_evaluation.py    # Split temporal dan metrik
│   ├── 6_ingest_data.py         # Wrapper CLI untuk modul nomor 0
│   └── 7_preprocess.py          # Wrapper CLI untuk modul nomor 1
├── notebooks/                  # Jupyter notebooks (EDA, PoC, eksperimen)
├── tests/                      # Unit tests komprehensif
│   ├── test_dags.py            # Pengujian DAG Airflow
│   ├── test_data_ingestion.py  # Pengujian pipeline ingestion
│   └── test_data_preprocessing.py # Pengujian Quality Gate, Anomaly Labeler, & Features
├── configs/                    # File konfigurasi
├── Documentation/              # Dokumen akademik (LK01, LK02, LK03, LK04)
│   ├── LK03/                   # Perancangan arsitektur data & DVC
│   └── LK04/                   # Laporan implementasi ingestion & preprocessing
├── .devcontainer/              # GitHub Codespaces configuration
├── requirements.txt            # Python dependencies
├── LICENSE                     # MIT License
└── README.md                   # Dokumentasi proyek
```

---

## 🚀 Cara Menjalankan

### Prerequisites

- Python 3.11+
- Git
- pip (Python package manager)

### Setup Environment (Lokal)

```bash
# 1. Clone repository
git clone https://github.com/<username>/MLOps-AnomaliCuacaOpenMeteo.git
cd MLOps-AnomaliCuacaOpenMeteo

# 2. Buat virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# atau
venv\Scripts\activate     # Windows

# 3. Install dependencies
pip install -r requirements.txt

# 4. Verifikasi instalasi
python -c "import requests; import pandas; print('Setup berhasil!')"
```

### Setup Environment (GitHub Codespaces)

1. Klik tombol hijau **"Code"** → **"Codespaces"** → **"Create codespace on main"**
2. Tunggu setup selesai (2-3 menit, otomatis install dependencies)
3. Verifikasi: `python --version`

### Menjalankan Pipeline Data

#### 1. Data Ingestion (Open-Meteo API)
Mengambil data cuaca per jam untuk Kota Malang dengan mekanisme retry backoff dan rolling buffer 30 hari (720 baris).

```bash
# Menjalankan modul ingestion utama
python src/0_data_ingestion.py

# Atau melalui entrypoint wrapper
python src/6_ingest_data.py --past-days 30 --buffer-size 720
```

#### 2. Data Preprocessing & Feature Engineering
Mengeksekusi Quality Gate, pelabelan anomali 3-kelas (Normal, Hardware Fault, Extreme Weather), dan ekstraksi 40 fitur temporal serta agrometeorologi (VPD, Dew Point, rolling statistics).

```bash
# Menjalankan modul preprocessing utama
python src/1_data_preprocessing.py

# Atau melalui entrypoint wrapper
python src/7_preprocess.py --input-path data/raw/weather_raw_current.csv --output-path data/processed/weather_features_v1.0.csv
```

#### 2b. Data Simulasi (Hardware Fault & Data Drift)
Open-Meteo adalah data model cuaca yang selalu bersih, sehingga Class 1 (Hardware Fault) tidak pernah muncul secara alami dan drift musiman butuh waktu berbulan-bulan untuk teramati. `src/3_simulate_data.py` membuat salinan data yang dimodifikasi di `data/simulated/` tanpa mengubah data asli di `data/raw/`. Label tetap diberikan oleh `AnomalyLabeler` saat preprocessing.

| Skenario | Perubahan | Kegunaan |
|---|---|---|
| `faults` | Merusak ±5% baris (OOB, nilai negatif, spike, glitch radiasi malam) + 1 blok sensor suhu stuck 18 jam | Contoh Class 1 untuk training |
| `drift` | Suhu +3°C, kelembaban −15%, presipitasi ×2 (meniru pergantian musim) | Pengujian Data Drift |

```bash
python src/3_simulate_data.py --scenario faults --fault-rate 0.05 --seed 42   # -> data/simulated/weather_faults_s42.csv
python src/3_simulate_data.py --scenario drift --temp-shift 3 --humidity-shift -15 --precip-scale 2

# Proses data simulasi dengan pipeline yang sama
python src/7_preprocess.py --input-path data/simulated/weather_faults_s42.csv \
    --output-path data/processed/weather_features_faults_s42.csv --current-path ""
```

Seed yang sama selalu menghasilkan file yang identik, sehingga dataset simulasi dapat direproduksi.

#### 3. Training Random Forest dan MLflow (LK06)

```bash
dvc pull
python train.py
python -m mlflow ui --backend-store-uri sqlite:///mlflow.db --host 127.0.0.1 --port 5000 --workers 1
```

Buka `http://127.0.0.1:5000`, pilih **Model training**, lalu eksperimen
`LK06-Weather-RandomForest`. Training memverifikasi hash DVC, membangun ulang
37 fitur dari snapshot raw simulasi, memakai 48 jam awal sebagai konteks,
dan membandingkan tiga konfigurasi RF dengan walk-forward validation.
20% observasi terakhir dipakai sebagai final test setelah parameter dipilih.
Model terpilih didaftarkan ke registry setelah pemeriksaan pemuatan ulang.

Hasil awal: RF tanpa class weighting menang dengan mean CV macro F1 0.8122;
test macro F1 0.9039. Recall hardware fault hanya 8/13 (61.54%). Label berasal
dari aturan dan fault sintetis; ini belum validasi sensor lapangan. Metadata,
kontrak inferensi berbasis histori, dan bukti lengkap ada pada
[dokumentasi LK06](Documentation/LK06/README.md).

SQLite dan artefak MLflow bersifat lokal, diabaikan Git; jalankan ulang training
di Codespaces untuk membuat tracking store di sana.

#### 3b. Model Registry dan inferensi Production (LK07)

Model aktif adalah **WeatherAnomalyRandomForest versi 1**, dengan stage
**Production** dan URI `models:/WeatherAnomalyRandomForest/Production`.
Pada 134 observasi holdout LK07 yang sama, V1 memiliki macro F1 0.6224
dan recall hardware fault 7/8; V2 memperoleh 0.5662 dan 5/8. V2 memakai
150 pohon dan dataset v4; V1 tetap dipertahankan. V3 merupakan registrasi
ulang artefak V2. Holdout tidak memiliki kelas extreme weather sehingga
keputusan ini terbatas pada simulasi akademik, belum validasi lapangan.

```bash
dvc pull Documentation/LK07/production_model.yaml.dvc
python scripts/verify_lk07_registry.py
```

Pemuatan model memerlukan tracking store dan artefak MLflow lokal yang cocok.
Script verifikasi memperbarui bukti dan metadata lokal; jika hasilnya dibekukan
kembali, perbarui pointer metadata dengan DVC. Lihat
[dokumentasi LK07](Documentation/LK07/README.md) untuk lineage, transisi stage,
kontrak 37 fitur dari histori 49 jam, dan laporan PDF.

#### 4. Menjalankan Unit Tests
Menjalankan 99 unit/integration tests yang mencakup DAG Airflow, ingestion,
preprocessing, simulasi, R2, kontrak training temporal, dan pemuatan model MLflow.

```bash
# Menjalankan seluruh rangkaian tes unit
python -m unittest discover tests
```

#### 5. Menjalankan Apache Airflow DAG (Opsional / VM Server)
```bash
# Verifikasi integritas DAG
python dags/weather_ingestion_dag.py

# Trigger DAG secara manual via Airflow CLI
airflow dags test weather_data_ingestion
```

---

## 📊 Data Source

Proyek ini menggunakan **[Open-Meteo API](https://open-meteo.com/)** sebagai sumber data tunggal.

| Parameter | Detail |
|---|---|
| **API Endpoint** | `https://api.open-meteo.com/v1/forecast` |
| **Lokasi** | Malang, Jawa Timur (-7.95, 112.61) |
| **Modalitas Data** | Tabular Time-Series |
| **Frekuensi Update** | Setiap 1 jam (micro-batch) |
| **Variabel** | temperature_2m, relative_humidity_2m, precipitation, soil_moisture_0_to_7cm |
| **Biaya** | Gratis (Open-Access, tanpa API key) |

---

## 🔧 Tech Stack

| Komponen | Teknologi | Fungsi |
|---|---|---|
| Language & Data Processing | Python & Pandas | Bahasa utama dan manipulasi data |
| Orchestration & Workflow | Apache Airflow | Scheduler dan workflow automation |
| Data Versioning | DVC | Version control untuk dataset |
| Experiment Tracking | MLflow | Tracking eksperimen dan model registry |
| Model Serving | FastAPI | REST API untuk inference |
| Containerization | Docker | Packaging aplikasi |
| Monitoring & Drift Detection | Evidently AI | Deteksi data drift dan concept drift |
| Visual Dashboard | Grafana | Visualisasi metrik dan monitoring |

---

## 📈 Pipeline MLOps

![Pipeline MLOps yang digunakan dalam project ini](Documentation/LK01/MLOps%20LK01-Page-1.jpg)

### 6.1 Diagram Alur End-to-End (Data → Training → Deployment → Monitoring)

#### **Tahap 1: Data Ingestion & Data Versioning (Setiap 1 Jam)**
- **Cara Kerja**: Apache Airflow mengeksekusi DAG harian/jam-jaman. Airflow mengirim HTTP GET Request ke Open-Meteo API.
- **Proses**:
  1. Data JSON dari API ditarik, diekstrak variabelnya (`temperature_2m`, `precipitation`, `soil_moisture`), dan diubah menjadi DataFrame Pandas.
  2. Data divalidasi (memastikan tidak ada kolom hilang). Data baru lalu digabungkan (*appended*) ke file `dataset_current.csv`.
  3. DVC (*Data Version Control*) mencatat hash MD5 dari file data terbaru. Ini memastikan kita bisa kembali (*rollback*) ke versi data jam tertentu jika ada masalah.

#### **Tahap 2: Continuous Training & Model Registry (Saat Trigger Aktif)**
- **Cara Kerja**: Jika Airflow menerima sinyal *Retraining Trigger* (jadwal 2 mingguan atau alarm dari Evidently AI), Airflow akan menjalankan *Retraining DAG*.
- **Proses**:
  1. Airflow memanggil script Python untuk *preprocessing*, *feature scaling*, dan melatih model (antara XGBoost / Random Forest) dengan data 30 hari terakhir.
  2. MLflow Tracking mencatat semua parameter (*hyperparameter*), metrik evaluasi (F1-Score, Confusion Matrix), dan menyimpan file artefak model (`model.pkl`).
  3. Model yang baru dilatih didaftarkan ke MLflow Model Registry dengan status **Staging** (Model Challenger).

#### **Tahap 3: Model Serving & Deployment (Real-Time Inference)**
- **Cara Kerja**: Model dipaketkan ke dalam FastAPI yang berjalan di dalam Docker Container.
- **Proses**:
  1. FastAPI membuka endpoint REST API (misal: `POST /predict`).
  2. Saat ada data baru dari Open-Meteo API, sistem memanggil endpoint tersebut.
  3. FastAPI memuat model dari MLflow, melakukan inferensi cepat (< 100 ms), dan mengembalikan respons JSON: `{"prediction": "Class 0", "confidence": 0.94}`.
  4. Dalam strategi **Shadow Deployment**, FastAPI mengeksekusi prediksi dari model Champion (Lama) dan model Challenger (Baru) secara beriringan untuk membandingkan akurasi di latar belakang.

#### **Tahap 4: Monitoring, Observability & Feedback Loop**
- **Cara Kerja**: Sistem tidak dilepas begitu saja, melainkan terus diawasi secara *real-time*.
- **Proses**:
  1. Setiap input data dari Open-Meteo API beserta hasil prediksi dari FastAPI dicatat ke dalam *Log Database*.
  2. Setiap hari, Evidently AI membandingkan data 24 jam terakhir dengan data *reference* saat training.
  3. Evidently menghitung statistik Data Drift dan Concept Drift.
  4. **Feedback Loop**: Jika Evidently menemukan drift score > 0.1, Evidently mengirimkan panggilan *Webhook / API Call* ke Apache Airflow untuk mengaktifkan kembali **Tahap 2 (Continuous Training)** secara otomatis.

---

## 🗂️ Data Versioning (DVC)

Dataset mentah (`data/raw/weather_raw_current.csv`) dilacak dengan **DVC**. Git hanya menyimpan file penunjuk kecil `weather_raw_current.csv.dvc` (berisi hash MD5 dan ukuran), sedangkan isi CSV disimpan di cache DVC dan di *remote storage* **Cloudflare R2** (bucket `weather-anomaly-mlops`, prefix `dvc/`, dapat diakses dari mana saja). Remote `vps` (SSH, hanya jaringan UB) tetap terdaftar sebagai cadangan.

Kredensial R2 tidak ada di repo. Isi sekali per mesin:

```bash
dvc remote modify --local r2 access_key_id <KEY_ID>
dvc remote modify --local r2 secret_access_key <SECRET>
```

### Mengapa versioning data krusial untuk reproduksibilitas model

Buffer data cuaca bersifat bergulir (30 hari / 720 baris): setiap jam data lama bergeser keluar dan data baru masuk, sehingga file yang sama berubah isinya dari waktu ke waktu. Tanpa versioning, model yang dilatih hari ini tidak dapat dilatih ulang persis dengan data yang sama minggu depan, dan hasil eksperimen tidak dapat dibandingkan secara adil. Dengan DVC, setiap model dapat dikaitkan ke satu tag data (misal `dataset-v1.0.0`) sehingga kombinasi **kode (commit Git) + data (hash DVC)** dapat dipulihkan kapan saja.

### Versi data yang tercatat

| Tag | Isi | Baris | Rentang waktu | MD5 (`.dvc`) |
|---|---|---|---|---|
| `dataset-v1.0.0` | Baseline dari LK-04 | 720 | 2026-08-29 s.d. 2026-09-27 | `e42dc025…` |
| `dataset-v2.0.0` | Setelah ingestion ulang (`--buffer-size 1000`) | 936 | 2026-08-29 s.d. 2026-10-06 | `8e441262…` |

### Alur menambah versi data baru

```bash
# 1. Ambil data tambahan (buffer diperbesar agar baris benar-benar bertambah)
python src/6_ingest_data.py --buffer-size 1000

# 2. Catat versi baru: hash di file .dvc berubah
dvc add data/raw/weather_raw_current.csv
git add data/raw/weather_raw_current.csv.dvc
git commit -m "data: update raw weather dataset v2"
git tag dataset-v2.0.0

# 3. Kirim isi data ke remote DULU, baru kirim pointer ke Git
dvc push --all-tags
git push origin <branch> --tags
```

### Audit dan perbandingan versi

```bash
dvc status                                        # workspace sinkron dengan .dvc?
dvc diff --show-hash dataset-v1.0.0 dataset-v2.0.0  # Modified: e42dc025..8e441262
git diff dataset-v1.0.0 dataset-v2.0.0 -- data/raw/weather_raw_current.csv.dvc
```

### Kembali ke versi tertentu / memulihkan data

```bash
git checkout dataset-v1.0.0 && dvc checkout   # CSV kembali ke 720 baris
git checkout <branch>       && dvc checkout   # CSV kembali ke versi terbaru
# Pada clone baru (jaringan apa pun): git pull && dvc pull
```

> **Catatan:** `dvc add` dijalankan manual pada momen penting (baseline, sebelum training), bukan setiap jam. Pengambilan data per jam tetap ditangani Airflow di VPS.

### Sinkronisasi otomatis Airflow (VPS) ke R2

Selain versi beku lewat DVC, DAG `weather_data_ingestion` punya task `upload_raw_to_r2` yang berjalan setelah ingestion dan mengunggah CSV lewat `src/2_r2_sync.py`:

| Key di bucket | Isi |
|---|---|
| `raw/weather_raw_<UTC>.csv` | Snapshot per run (riwayat tidak hilang walau buffer bergulir) |
| `raw/latest.csv` | Salinan terbaru (ditimpa tiap run) |

Kredensial dibaca dari `.env` di root repo (salin dari `.env.example`, sudah di-`.gitignore`).

```bash
python src/2_r2_sync.py upload      # dijalankan Airflow di VPS
python src/2_r2_sync.py list        # lihat snapshot di bucket
python src/2_r2_sync.py download    # laptop: ambil raw/latest.csv ke data/raw/
```

Alur lengkap: Airflow upload ke R2, laptop `download` data terbaru, lalu bila ingin dibekukan sebagai versi training: `dvc add` + `git commit` + `dvc push`.

---

## 🎯 Kriteria Sukses

### Metrik Teknis
- **F1-Score** > 85%
- **Latency Inference** < 500 ms
- **API Availability** > 99.9%

### Metrik Bisnis
- Pengurangan pengecekan manual **40%**
- Pencegahan kegagalan aktuator
- Downtime kalibrasi mendekati **nol**

---

## 📖 Dokumentasi Akademik

| Dokumen | Deskripsi |
|---|---|
| [LK01](Documentation/LK01/LK01-Muhammad%20Ghazy%20Humaidi-245150200111071.pdf) | Rancangan sistem MLOps lengkap |
| [LK02 - Kriteria Penilaian](Documentation/LK02/LK02-Grading-Criteria.md) | Indikator & kriteria penilaian |
| [LK03 - Perancangan Arsitektur Data](Documentation/LK03/LK03-Perancangan-Arsitektur-Data.md) | Desain pipeline ETL, skema data awal & DVC |
| [LK04 - Ingestion & Preprocessing](Documentation/LK04/LK04-Muhammad%20Ghazy%20Humaidi-245150200111071.pdf) | Implementasi Airflow ingestion, Quality Gate, Anomaly Labeling, & Feature Engineering |
| [LK05 - Data Versioning DVC](Documentation/LK05/LK05-Muhammad%20Ghazy%20Humaidi-245150200111071.pdf) | Pelacakan dataset dengan DVC, simulasi data baru, & audit diff antar versi |
| [LK06 - Random Forest & MLflow](Documentation/LK06/README.md) | EDA, walk-forward tuning, registry, metadata model, dan laporan eksperimen |
| [LK07 - Model Registry & Kesiapan Inferensi](Documentation/LK07/README.md) | Versioning, transisi stage, metadata DVC, pemilihan Production, dan bukti inferensi |
| [GitHub Flow Guide](Documentation/LK02/GITHUB_FLOW.md) | Panduan branching strategy |

---

## 🤝 Informasi Proyek

| | |
|---|---|
| **Nama** | Muhammad Ghazy Humaidi |
| **NIM** | 245150200111071 |
| **Mata Kuliah** | MLOps - TIF-B 2026 |
| **Dosen** | Rizal Setya Perdana, S.Kom., M.Kom., Ph.D. |
| **Program Studi** | Teknik Informatika |
| **Universitas** | Universitas Brawijaya |

---

## 📄 Lisensi

Proyek ini dilisensikan di bawah [MIT License](LICENSE).
